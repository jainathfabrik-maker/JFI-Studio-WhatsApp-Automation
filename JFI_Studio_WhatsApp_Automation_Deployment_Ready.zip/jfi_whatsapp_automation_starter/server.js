import 'dotenv/config';
import express from 'express';
import crypto from 'node:crypto';
import cron from 'node-cron';

const app = express();
app.use(express.json({
  verify: (req, res, buf) => { req.rawBody = Buffer.from(buf); }
}));

const required = [
  'OPENAI_API_KEY', 'WHATSAPP_PHONE_NUMBER_ID', 'WHATSAPP_ACCESS_TOKEN',
  'WHATSAPP_VERIFY_TOKEN', 'WHATSAPP_APP_SECRET', 'WHATSAPP_RECIPIENT',
  'WHATSAPP_TEMPLATE_NAME', 'WHATSAPP_TEMPLATE_LANGUAGE', 'WHATSAPP_GRAPH_VERSION'
];
function missingEnv() { return required.filter(k => !process.env[k] || process.env[k].includes('vXX')); }

function verifyMetaSignature(req) {
  const secret = process.env.WHATSAPP_APP_SECRET;
  const header = req.get('x-hub-signature-256') || '';
  if (!secret || !header.startsWith('sha256=')) return false;
  const expected = 'sha256=' + crypto.createHmac('sha256', secret).update(req.rawBody || Buffer.alloc(0)).digest('hex');
  const a = Buffer.from(header);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// Meta webhook subscription verification.
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN && challenge) {
    return res.status(200).send(String(challenge));
  }
  return res.sendStatus(403);
});

// Webhook events (message status and inbound events). Never log tokens or full payloads.
app.post('/webhook', (req, res) => {
  if (!verifyMetaSignature(req)) return res.sendStatus(401);
  const body = req.body;
  const changes = body?.entry?.flatMap(e => e.changes || []) || [];
  for (const change of changes) {
    const value = change.value || {};
    for (const status of value.statuses || []) {
      console.log('WhatsApp status:', status.status, 'message_id:', status.id);
    }
    for (const message of value.messages || []) {
      console.log('Incoming WhatsApp message received; type:', message.type);
    }
  }
  return res.sendStatus(200);
});

async function generateContentPack() {
  const prompt = `Create today's ready-to-publish content pack for JFI Studio, an architect-led turnkey interior studio in Bengaluru, India.
Use mixed English + natural Kannada where appropriate. Rotate among these pillars: proof of work, price transparency, process, education, people, trust.
Return a concise, useful daily pack with: format/length, pillar, objective, on-screen hook (max 12 words, contains a number or place name), short script, shot list, caption with WhatsApp CTA, hashtags, cover text, story idea, filming check, tomorrow teaser.
Never invent project results, testimonials, client details, or prices. Avoid the words luxury, dream, transform, seamless, elevate.
This is a message that may be sent through a WhatsApp template variable; keep it concise enough to fit one practical message.`;
  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || 'gpt-5.4-mini',
      input: prompt,
      max_output_tokens: 900
    })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`OpenAI API failed (${response.status}): ${JSON.stringify(data.error || {})}`);
  const text = data.output_text || (data.output || [])
    .flatMap(item => item.content || [])
    .filter(item => item.type === 'output_text')
    .map(item => item.text).join('\\n');
  if (!text) throw new Error('OpenAI returned no text output.');
  return text;
}

async function sendApprovedTemplate(contentPack) {
  const senderId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  const recipient = String(process.env.WHATSAPP_RECIPIENT || '').replace(/\\D/g, '');
  // Prevent accidental self-send attempts: recipient should be a customer/team user's number.
  // Set WHATSAPP_SENDER_NUMBER in .env if you want this guard to compare against the business number.
  const senderNumber = String(process.env.WHATSAPP_SENDER_NUMBER || '').replace(/\\D/g, '');
  if (!recipient) throw new Error('WHATSAPP_RECIPIENT is missing.');
  if (senderNumber && recipient === senderNumber) {
    throw new Error('Recipient equals sender. Self-messaging is not a dependable supported workflow; configure a separate recipient.');
  }

  const url = `https://graph.facebook.com/${process.env.WHATSAPP_GRAPH_VERSION}/${senderId}/messages`;
  const payload = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: recipient,
    type: 'template',
    template: {
      name: process.env.WHATSAPP_TEMPLATE_NAME,
      language: { code: process.env.WHATSAPP_TEMPLATE_LANGUAGE || 'en' },
      components: [{
        type: 'body',
        parameters: [{ type: 'text', text: contentPack.slice(0, 900) }]
      }]
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`WhatsApp API failed (${response.status}): ${JSON.stringify(data)}`);
  console.log('WhatsApp API accepted message; message id:', data.messages?.[0]?.id || 'unknown');
}

async function runDaily() {
  const missing = missingEnv();
  if (missing.length) throw new Error(`Missing configuration: ${missing.join(', ')}`);
  const pack = await generateContentPack();
  await sendApprovedTemplate(pack);
}

app.get('/health', (req, res) => res.json({ ok: true, service: 'jfi-studio-whatsapp-automation' }));

app.post('/admin/run-daily', async (req, res) => {
  const adminKey = process.env.ADMIN_TRIGGER_TOKEN;
  if (!adminKey || req.get('authorization') !== `Bearer ${adminKey}`) return res.sendStatus(401);
  try {
    await runDaily();
    return res.json({ ok: true, message: 'Generation and send request completed.' });
  } catch (err) {
    console.error(err.message);
    return res.status(500).json({ ok: false, error: err.message });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`JFI automation listening on port ${port}`));

const cronSpec = process.env.DAILY_CRON || '30 8 * * *';
const timezone = process.env.TIMEZONE || 'Asia/Kolkata';
if (cron.validate(cronSpec)) {
  cron.schedule(cronSpec, async () => {
    try { await runDaily(); }
    catch (err) { console.error('Daily run failed:', err.message); }
  }, { timezone });
} else {
  console.error('Invalid DAILY_CRON; scheduled delivery disabled.');
}
