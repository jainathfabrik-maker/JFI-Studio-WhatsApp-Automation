# JFI Studio WhatsApp Automation — starter

This is a starter project, not a deployed service. It does not contain credentials and does not activate anything in Meta or OpenAI until you deploy it and configure the secrets.

## Important limitation: same sender and recipient

WhatsApp Cloud API is intended for a business number to message a recipient. Sending a scheduled pack to the exact same number used as the API sender is not a dependable supported workflow. This starter should be configured with a separate personal/team recipient. The code can block a known same-number configuration if you set `WHATSAPP_SENDER_NUMBER`.

## What it does

- Runs daily at 08:30 `Asia/Kolkata` by default.
- Uses the OpenAI Responses API to generate a concise JFI Studio content pack.
- Sends the pack through an approved WhatsApp template.
- Exposes `/webhook` for Meta verification and message/status events.
- Exposes `/health` for a basic health check.
- Exposes `/admin/run-daily` for an authenticated manual run.

## Requirements

- Node.js 20+
- Public HTTPS hosting with persistent service/scheduler support
- OpenAI API key (API billing is separate from a ChatGPT subscription)
- Meta WhatsApp Cloud API phone-number ID and long-lived/system-user access token
- Meta app secret and webhook verification token
- An approved WhatsApp template named as configured in `.env`
- A separate recipient number in international format

## Configure locally

1. Copy `.env.example` to `.env`.
2. Fill in credentials privately; never paste them into chat or commit `.env`.
3. Set `WHATSAPP_GRAPH_VERSION` to a currently supported Graph API version shown in your Meta app/docs (replace `vXX.X`).
4. Set `WHATSAPP_SENDER_NUMBER` to your business number in digits-only international format if you want the self-send guard.
5. Set `WHATSAPP_RECIPIENT` to a different number you control.
6. Create/approve a WhatsApp message template in WhatsApp Manager. It must have one body variable for the content pack, because the code supplies one template variable. The template category and approval are determined by Meta; do not assume a daily business-initiated message is a utility template.
7. Install and run:
   ```bash
   npm install
   npm start
   ```
8. Deploy to a host with a public HTTPS URL. Set the Meta callback URL to `https://YOUR-HOST/webhook` and the same `WHATSAPP_VERIFY_TOKEN` value in Meta and the environment.
9. Subscribe the app to the `messages` webhook field in the Meta app dashboard.
10. Use the protected admin endpoint for a test:
    ```bash
    curl -X POST https://YOUR-HOST/admin/run-daily \
      -H "Authorization: Bearer YOUR_ADMIN_TRIGGER_TOKEN"
    ```
    Add a long random `ADMIN_TRIGGER_TOKEN` to `.env` before using this endpoint.

## Important implementation notes

- The template must be approved and its variable structure must match this code. Meta may reject a long variable or a template whose structure does not match; for a full content pack, it may be better to send a short template with a link to a hosted document, or use multiple approved templates.
- API acceptance is not proof of delivery. Check WhatsApp status webhooks for `sent`, `delivered`, `read`, or `failed`.
- The webhook signature is verified with `WHATSAPP_APP_SECRET`.
- This starter does not publish your Meta app, verify your business, create an access token, or deploy itself.
- Add persistent logs, retries, idempotency, alerting, and secret-manager storage before relying on it for production.
- For privacy, do not log tokens or full incoming message bodies.

## Official references

- Meta Cloud API: https://developers.facebook.com/docs/whatsapp/cloud-api/get-started
- Meta WhatsApp Cloud API collection: https://www.postman.com/meta/whatsapp-business-platform/documentation/wlk6lh4/whatsapp-cloud-api
- OpenAI Responses API: https://developers.openai.com/api/reference/responses/overview
